from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

# Beispiel-Datenbank mit Tags
database = [
    {
        "id": 1,
        "title": "Objekt A",
        "image": "static/uploads/UploadedImage0.jpg",
        "created": "2023-01-01",
        "description": "Dies ist eine Beschreibung von Objekt A.",
        "tags": ["rot", "klein", "rund"]
    },
    {
        "id": 2,
        "title": "Objekt B",
        "image": "static/uploads/UploadedImage1.jpg",
        "created": "2023-02-15",
        "description": "Dies ist eine Beschreibung von Objekt B.",
        "tags": ["blau", "groß", "eckig"]
    },
    {
        "id": 3,
        "title": "Objekt C",
        "image": "static/uploads/UploadedImage2.jpg",
        "created": "2023-03-10",
        "description": "Dies ist eine Beschreibung von Objekt C.",
        "tags": ["grün", "mittel", "oval"]
    },
    {
        "id": 4,
        "title": "Objekt D",
        "image": "static/uploads/UploadedImage3.jpg",
        "created": "2023-04-05",
        "description": "Dies ist eine Beschreibung von Objekt D.",
        "tags": ["gelb", "klein", "dreieckig"]
    }
]

@app.route('/')
def index():
    return render_template("index.html", data=database)

@app.route('/filter', methods=['POST'])
def filter_data():
    filters = request.get_json()
    title_filter = filters.get('title', '').lower()
    tag_filter = filters.get('tag', '').lower()
    date_filter = filters.get('date', '')

    def matches(entry):
        title_match = title_filter in entry['title'].lower() if title_filter else True
        tag_match = any(tag_filter in tag.lower() for tag in entry.get('tags', [])) if tag_filter else True
        date_match = entry['created'] == date_filter if date_filter else True
        return title_match and tag_match and date_match

    filtered = [entry for entry in database if matches(entry)]
    return jsonify(filtered)

if __name__ == '__main__':
    app.run(debug=True)
