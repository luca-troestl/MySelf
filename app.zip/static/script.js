function renderCards(items) {
  const container = document.getElementById('recordList');
  container.innerHTML = '';
  items.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';
    card.onclick = () => showDetails(item);
    card.innerHTML = `
      <img src="${item.image}" alt="${item.title}">
      <div class="card-body">
        <div class="card-title">${item.title}</div>
        <div class="card-text">${item.description.substring(0, 80)}...</div>
      </div>
    `;
    container.appendChild(card);
  });
}

function showDetails(item) {
  const detail = document.getElementById('detailContent');
  detail.innerHTML = `
    <h3>${item.title}</h3>
    <img src="${item.image}" alt="${item.title}">
    <p><strong>Erstellt am:</strong> ${item.created}</p>
    <p>${item.description}</p>
    <p><strong>Tags:</strong> ${item.tags ? item.tags.join(', ') : ''}</p>
  `;
}

function applyFilters() {
  const title = document.getElementById('filterTitle').value;
  const date = document.getElementById('filterDate').value;
  const tags = document.getElementById('filterTags').value.split(',').map(t => t.trim()).filter(t => t);

  fetch('/filter', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, date, tag: tags[0] || '' })
  })
  .then(res => res.json())
  .then(data => {
    renderCards(data);
    document.getElementById('detailContent').innerHTML = "<h3>Details</h3><p>Wähle ein Objekt aus der Liste.</p>";
  });
}

window.onload = () => {
  applyFilters();
};
